java -jar TP1.jar fasta/chromosome13_NT_009952.14.fasta 10
java -jar TP1.jar fasta/chromosome13_NT_009952.14.fasta 15
java -jar TP1.jar fasta/chromosome13_NT_009952.14.fasta 20
java -jar TP1.jar fasta/chromosome13_NT_009952.14.fasta 30
