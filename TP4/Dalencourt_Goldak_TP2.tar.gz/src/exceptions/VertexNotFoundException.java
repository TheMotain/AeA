package exceptions;

/**
 * Created by dalencourt on 27/03/17.
 */
public class VertexNotFoundException extends Exception {
}
