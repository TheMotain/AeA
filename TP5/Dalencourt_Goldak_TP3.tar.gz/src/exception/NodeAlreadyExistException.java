package exception;

/**
 * Exception
 */
public class NodeAlreadyExistException extends Exception{
}
