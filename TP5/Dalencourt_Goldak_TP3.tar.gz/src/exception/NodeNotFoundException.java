package exception;

/**
 * Exception
 */
public class NodeNotFoundException extends Exception {
}
